﻿IFTO – Campus DNO 

Aluno: Felipe Dias, Elizane Urcino Serie: 3º ano  

Tutorial e respostas das perguntas 

**Em um controlador como o que construímos, como garantir que somente requisições válidas serão repassadas ao banco de dados?** 

O express-validator é uma biblioteca que pode ser utilizada no Node.js com o express, para realizar a validação dos dados de entrada na API. 

Os middlewares no Express são funções que tem acesso ao objeto de requisição, resposta e próximo middleware, com isso você pode adicioná-lo por exemplo entre a chamada de acesso a API e o salvamento dos dados, e isso possibilita a validação antes dos dados serem persistidos em um banco. 

Para este post, o express-validator utilizado foi o da versão 6.6.1 e um pré-requisito é que o Node.js esteja na versão 6. 

Para realizar a instalação, utilize o comando: 

![](Aspose.Words.0e88e1f4-8773-4c31-9ab7-58a3e3d3e308.001.png)

Para realizar a validação dos dados da API, é necessário realizar a importação de body e validationResult, o body vai servir para validar os dados de entrada e o validationResult conterá o resultado se a entrada é válida ou não. 

Posterior a essa importação, é necessário colocar a validação como um middleware na request, e é possível fazer isso utilizando um array antes do request e response, dessa forma: 

app.post('/user', [ 

21    //validação dos dados 

3   body('username').isEmail(), 

`  `body('password').isLength({ min: 5 }) 

4  ], (req, res) => { 

5   // caso encontre erros, ficará nessa variável errors 

6   const errors = validationResult(req); 

7   if (!errors.isEmpty()) { 

8     return res.status(400).send(‘Não foi possível encontrar o usuário por 9  favor ensira seus dados novamente’); 

10   } 

11 

12  

13  } ) ;/ /se os dados forem válidos, o sistema executará aqui

**Como responder ao usuário em caso de uma entrada incorreta?** 

Se isso ocorrer a estrutura condicional entrara em ação, fazendo com que o if() seja considerado e a assim o comando return aja informando o tipo de erro e a mensagem descrita ao usuário, que reescreva seus dados novamente no exemplo do código acima.   

Referencias:[ https://programandosolucoes.dev.br/2020/11/10/valida-api- express-validator/ ](https://programandosolucoes.dev.br/2020/11/10/valida-api-express-validator/)

[https://www.youtube.com/watch?v=FlH_rw8_B0c ](https://www.youtube.com/watch?v=FlH_rw8_B0c) 
